prompt --application/shared_components/logic/application_items/user_tenant
begin
--   Manifest
--     APPLICATION ITEM: USER_TENANT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>2200408020639491
,p_default_application_id=>138
,p_default_id_offset=>39318793634258964
,p_default_owner=>'JASOLAR'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(9715290900046514589)
,p_name=>'USER_TENANT'
,p_protection_level=>'I'
,p_version_scn=>6666071215100
);
wwv_flow_imp.component_end;
end;
/
